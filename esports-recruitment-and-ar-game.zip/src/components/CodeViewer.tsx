import { useState } from 'react';
import { Copy, Download, Check, FileCode, Database, HelpCircle, HardDrive, Terminal } from 'lucide-react';
import { xamppProjectFiles, PHPFile } from '../data/phpCode';

export default function CodeViewer() {
  const [activeFileIndex, setActiveFileIndex] = useState(0);
  const [copied, setCopied] = useState<number | null>(null);

  const activeFile = xamppProjectFiles[activeFileIndex];

  // ฟังก์ชันดาวน์โหลดไฟล์แต่ละไฟล์โดยตรงจากเบราว์เซอร์
  const handleDownloadFile = (file: PHPFile) => {
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = file.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // ฟังก์ชันคัดลอกโค้ดไปยังคลิปบอร์ด
  const handleCopyCode = (text: string, index: number) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(index);
      setTimeout(() => setCopied(null), 2000);
    });
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl w-full flex flex-col lg:flex-row">
      
      {/* รายชื่อไฟล์ฝั่งซ้าย */}
      <div className="w-full lg:w-72 border-b lg:border-b-0 lg:border-r border-slate-800 bg-slate-950/40 p-5 shrink-0 space-y-4">
        <div>
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5 flex items-center gap-1.5">
            <HardDrive className="w-4 h-4 text-cyan-400" />
            โครงสร้างไฟล์ XAMPP
          </h3>
          <p className="text-[11px] text-slate-400">
            เซฟไฟล์ทั้งหมดนี้ลงในโฟลเดอร์ <code className="bg-slate-900 px-1 py-0.5 rounded text-white text-[10px]">C:\xampp\htdocs\esports-recruit\</code>
          </p>
        </div>

        <div className="space-y-1">
          {xamppProjectFiles.map((file, idx) => (
            <button
              key={idx}
              onClick={() => setActiveFileIndex(idx)}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-xs font-medium flex items-center justify-between transition ${
                activeFileIndex === idx
                  ? 'bg-indigo-600/10 text-indigo-300 border border-indigo-500/30'
                  : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-2 truncate">
                {file.language === 'sql' ? (
                  <Database className="w-4 h-4 text-indigo-400 shrink-0" />
                ) : file.language === 'markdown' ? (
                  <HelpCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <FileCode className="w-4 h-4 text-cyan-400 shrink-0" />
                )}
                <span className="font-mono truncate">{file.filename}</span>
              </div>
              
              <span className={`text-[9px] uppercase px-1.5 py-0.5 rounded shrink-0 font-mono ${
                file.language === 'sql' ? 'bg-indigo-950/60 text-indigo-300 border border-indigo-900/30' :
                file.language === 'markdown' ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-900/30' :
                'bg-cyan-950/60 text-cyan-300 border border-cyan-900/30'
              }`}>
                {file.language}
              </span>
            </button>
          ))}
        </div>

        {/* แนะนำเครื่องมือด่วน */}
        <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800/80 space-y-1.5">
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">⚡ ประหยัดเวลาการสร้างไฟล์</span>
          <p className="text-[10px] text-slate-400 leading-normal">
            คุณสามารถคลิกปุ่มดาวน์โหลดที่ตัวโค้ดเพื่อบันทึกไฟล์นั้นเข้าเครื่องทันที โดยไม่ต้องไปเปิดสร้างไฟล์ว่างในโปรแกรมสตรีมโค้ด
          </p>
        </div>
      </div>

      {/* พื้นที่แสดงซอร์สโค้ดฝั่งขวา */}
      <div className="flex-grow flex flex-col bg-slate-900/20">
        
        {/* หัวข้อแสดงไฟล์ปัจจุบันและปุ่มดาวน์โหลด/คัดลอก */}
        <div className="border-b border-slate-800 bg-slate-950/20 px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-base font-bold text-white">{activeFile.filename}</span>
              <span className="text-[11px] text-slate-400">({activeFile.description})</span>
            </div>
          </div>
          
          <div className="flex gap-2 w-full sm:w-auto">
            <button
              onClick={() => handleCopyCode(activeFile.content, activeFileIndex)}
              className="flex-1 sm:flex-none bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition"
            >
              {copied === activeFileIndex ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  คัดลอกแล้ว!
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  คัดลอกโค้ด
                </>
              )}
            </button>
            <button
              onClick={() => handleDownloadFile(activeFile)}
              className="flex-1 sm:flex-none bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition shadow-lg shadow-indigo-600/10"
            >
              <Download className="w-3.5 h-3.5" />
              ดาวน์โหลดไฟล์
            </button>
          </div>
        </div>

        {/* ตัวกล่องใส่โค้ด */}
        <div className="p-6 overflow-auto max-h-[500px] bg-slate-950/60 font-mono text-xs text-slate-300 leading-relaxed border-b border-slate-800">
          {activeFile.language === 'markdown' ? (
            // แสดงผลไกด์คู่มือจัดวางเป็นระเบียบ
            <div className="prose prose-invert max-w-none text-slate-300 text-xs">
              <pre className="whitespace-pre-wrap font-sans leading-relaxed text-slate-300 border-none p-0 bg-transparent text-sm">
                {activeFile.content}
              </pre>
            </div>
          ) : (
            // แสดงกล่องโค้ดโปรแกรมเมอร์
            <pre className="whitespace-pre overflow-x-auto text-cyan-300/90 text-[11px] font-mono leading-relaxed">
              <code>{activeFile.content}</code>
            </pre>
          )}
        </div>

        {/* แถบแจ้งเตือนล่างสุด */}
        <div className="px-6 py-3.5 bg-slate-950/30 flex items-center gap-2 text-slate-500 text-[11px]">
          <Terminal className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
          <span>โครงสร้างโปรเจกต์นี้ได้รับการดีไซน์ด้วยมาตรฐาน PDO (PHP Data Objects) เพื่อป้องกันภัยคุกคาม <strong className="text-slate-400 font-medium">SQL Injection</strong> 100%</span>
        </div>

      </div>

    </div>
  );
}
