import React, { useState } from 'react';
import { LogIn, UserPlus, Trophy, Users, Shield, Zap, Target, ArrowRight } from 'lucide-react';
import { User, ActiveView } from '../types';

interface InfoHomeProps {
  onLogin: (username: string, passwordHash: string) => boolean;
  onNavigate: (view: ActiveView) => void;
  successMessage?: string;
}

export default function InfoHome({ onLogin, onNavigate, successMessage }: InfoHomeProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!username.trim() || !password) {
      setError('กรุณากรอกข้อมูลให้ครบถ้วน!');
      return;
    }

    const success = onLogin(username.trim(), password);
    if (!success) {
      setError('ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง! (หรือลองใช้บัญชีทดสอบ admin รหัสผ่าน 123456)');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center w-full">
      
      {/* ข้อมูลเกี่ยวกับสโมสร / ทีมจำลอง (ฝั่งซ้าย) */}
      <div className="lg:col-span-7 space-y-6">
        <div className="inline-flex items-center gap-1.5 bg-indigo-900/40 text-indigo-300 border border-indigo-700/50 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider">
          <Zap className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
          NEXUS ESPORTS CAMPAIGN 2026
        </div>
        
        <h1 className="text-4xl md:text-5xl font-black tracking-tight text-white leading-none">
          ก้าวสู่การเป็นนักกีฬา <br />
          <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-500 bg-clip-text text-transparent">ระดับมืออาชีพ</span> กับเรา!
        </h1>
        
        <p className="text-slate-400 text-sm md:text-base leading-relaxed max-w-xl">
          ยินดีต้อนรับเข้าสู่ระบบรับสมัครนักกีฬา Esports และระบบทดสอบสมรรถภาพของสโมสร Nexus Esports สโมสรชั้นนำระดับประเทศ 
          นี่คือระบบจำลองสถานการณ์คัดตัวด้วยแอปพลิเคชัน AR (Augmented Reality) ผ่านกล้องเว็บแคมเพื่อจับเวลาและสแกนปฏิกิริยาความไว
        </p>

        {/* จุดเด่นทีม */}
        <div className="grid grid-cols-3 gap-4 pt-2">
          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
            <div className="text-2xl font-black text-cyan-400 font-mono">#1</div>
            <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wide">Thailand League</div>
          </div>
          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
            <div className="text-2xl font-black text-indigo-400 font-mono">24/7</div>
            <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wide">Gaming House</div>
          </div>
          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
            <div className="text-2xl font-black text-violet-400 font-mono">100K+</div>
            <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wide">Base Salary</div>
          </div>
        </div>

        {/* ไฮไลต์คุณสมบัติเด่นของระบบเว็บ */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <div className="flex gap-3 items-start p-3.5 bg-slate-900/40 border border-slate-800/60 rounded-xl">
            <div className="p-2 bg-cyan-950 text-cyan-400 rounded-lg shrink-0">
              <Target className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white mb-0.5">AR Reflex Test (Game.php)</h4>
              <p className="text-[10px] text-slate-400 leading-normal">
                ใช้เทคโนโลยีกล้องในการจับการขยับมือเพื่อทำคะแนนแบบเรียลไทม์ผ่าน API
              </p>
            </div>
          </div>

          <div className="flex gap-3 items-start p-3.5 bg-slate-900/40 border border-slate-800/60 rounded-xl">
            <div className="p-2 bg-indigo-950 text-indigo-400 rounded-lg shrink-0">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white mb-0.5">User System (Register.php)</h4>
              <p className="text-[10px] text-slate-400 leading-normal">
                สมัครสมาชิกใหม่เข้าระบบเพื่อบันทึกสถิติส่วนบุคคลลง MySQL PDO
              </p>
            </div>
          </div>
        </div>

        {/* พินแนะนำการล็อกอินทดสอบ */}
        <div className="p-4 bg-slate-900/30 rounded-xl border border-slate-800/80 flex items-start gap-3">
          <span className="text-lg text-yellow-500 shrink-0">✨</span>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            <strong className="text-slate-200">เข้าทดสอบอย่างรวดเร็ว:</strong> คุณสามารถทดลองล็อกอินเข้าระบบด้วยไอดีจำลอง 
            <code className="bg-slate-950 text-yellow-400 font-mono px-1 py-0.5 rounded text-[10px] mx-1">username: admin</code> และ 
            <code className="bg-slate-950 text-yellow-400 font-mono px-1 py-0.5 rounded text-[10px] mx-1">password: 123456</code> เพื่อเล่นเกม AR ได้ทันที หรือกดสมัครสมาชิกเพื่อสร้างบัญชีส่วนตัวใหม่ก็ได้เช่นกัน!
          </p>
        </div>
      </div>

      {/* กล่องล็อกอินเข้าสู่ระบบ (ฝั่งขวา) */}
      <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-xl max-w-md w-full mx-auto">
        <h2 className="text-xl font-bold text-white mb-1">เข้าสู่ระบบคัดตัว</h2>
        <p className="text-xs text-slate-400 mb-6">กรอกข้อมูลบัญชีเพื่อทดสอบ AR Reaction Speed</p>

        {/* แสดงข้อความเมื่อสมัครสมาชิกเสร็จแล้วย้อนกลับมาหน้านี้ */}
        {successMessage && (
          <div className="bg-emerald-950/50 border border-emerald-500/30 text-emerald-300 p-3 rounded-xl text-xs mb-4">
            {successMessage}
          </div>
        )}

        {error && (
          <div className="bg-red-950/50 border border-red-500/30 text-red-300 p-3 rounded-xl text-xs mb-4">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">ชื่อผู้ใช้งาน (Username)</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="กรอกชื่อผู้ใช้งาน หรือ admin"
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-3 text-slate-100 text-xs outline-none transition"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">รหัสผ่าน (Password)</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="กรอกรหัสผ่าน หรือ 123456"
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-3 text-slate-100 text-xs outline-none transition"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3.5 rounded-xl text-xs uppercase tracking-wider transition shadow-lg shadow-indigo-600/10 flex justify-center items-center gap-1.5 cursor-pointer mt-2"
          >
            <LogIn className="w-4 h-4" />
            เข้าสู่ระบบสโมสร
          </button>
        </form>

        <div className="relative flex py-4 items-center">
          <div className="flex-grow border-t border-slate-800"></div>
          <span className="flex-shrink mx-4 text-slate-500 text-[10px] uppercase font-mono tracking-wider">หรือ</span>
          <div className="flex-grow border-t border-slate-800"></div>
        </div>

        <div className="flex flex-col gap-2.5">
          <button
            onClick={() => onNavigate('register')}
            className="w-full bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white font-semibold py-3 rounded-xl text-xs transition flex justify-center items-center gap-1.5 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            สมัครสมาชิกใหม่ (Register.php)
          </button>
          
          <button
            onClick={() => onNavigate('export')}
            className="w-full bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 py-3 rounded-xl text-[11px] font-medium transition flex justify-center items-center gap-1.5 cursor-pointer"
          >
            ดูโค้ด PHP/SQL ทั้งหมดสำหรับ XAMPP
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

    </div>
  );
}
