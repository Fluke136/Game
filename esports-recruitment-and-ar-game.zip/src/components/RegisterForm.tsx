import React, { useState } from 'react';
import { UserPlus, ArrowLeft, ShieldCheck, Check } from 'lucide-react';
import { ActiveView } from '../types';

interface RegisterFormProps {
  onRegister: (username: string, passwordHash: string) => { success: boolean; message: string };
  onNavigate: (view: ActiveView) => void;
}

export default function RegisterForm({ onRegister, onNavigate }: RegisterFormProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [agree, setAgree] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // ตรวจสอบความถูกต้องเบื้องต้นตามข้อกำหนดเดียวกับ PHP
    if (!username.trim() || !password || !confirmPassword) {
      setError('กรุณากรอกข้อมูลให้ครบถ้วน!');
      return;
    }

    if (username.trim().length < 4) {
      setError('ชื่อผู้ใช้งานต้องมีความยาวอย่างน้อย 4 ตัวอักษร!');
      return;
    }

    if (password.length < 6) {
      setError('รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร!');
      return;
    }

    if (password !== confirmPassword) {
      setError('รหัสผ่านและการยืนยันรหัสผ่านไม่ตรงกัน!');
      return;
    }

    if (!agree) {
      setError('กรุณากดยินยอมรับเงื่อนไขในการสแกนสิทธิ์เข้าคัดตัว!');
      return;
    }

    const res = onRegister(username.trim(), password);
    if (res.success) {
      setIsSuccess(true);
      setTimeout(() => {
        // บันทึกสำเร็จ นำกลับไปหน้าแรกพร้อมล็อกอินได้ทันที
        onNavigate('home');
      }, 1500);
    } else {
      setError(res.message);
    }
  };

  return (
    <div className="max-w-md w-full mx-auto bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-xl">
      <div className="flex justify-between items-center mb-6">
        <button
          onClick={() => onNavigate('home')}
          className="text-slate-400 hover:text-white transition flex items-center gap-1 text-xs font-semibold cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          ย้อนกลับ
        </button>
        <span className="text-[10px] bg-slate-950 px-2.5 py-1 rounded text-indigo-400 border border-slate-800 font-mono">Register.php</span>
      </div>

      <h2 className="text-xl font-bold text-white mb-1">สมัครเข้าทีม Nexus</h2>
      <p className="text-xs text-slate-400 mb-6">สร้างบัญชีสำหรับทดสอบวัดระดับและจัดอันดับผู้เล่น</p>

      {error && (
        <div className="bg-red-950/50 border border-red-500/30 text-red-300 p-3 rounded-xl text-xs mb-4">
          {error}
        </div>
      )}

      {isSuccess && (
        <div className="bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 p-4 rounded-xl text-xs mb-4 flex items-center gap-2">
          <Check className="w-4 h-4 shrink-0" />
          <span>สมัครสมาชิกสำเร็จเรียบร้อย! กำลังนำคุณกลับไปหน้าแรกสำหรับล็อกอิน...</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">ชื่อผู้ใช้งาน (Username)</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="ตัวภาษาอังกฤษหรือตัวเลข 4 ตัวอักษรขึ้นไป"
            className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-3 text-slate-100 text-xs outline-none transition"
            required
            disabled={isSuccess}
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">รหัสผ่าน (Password)</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="รหัสผ่านความยาวอย่างน้อย 6 ตัวอักษร"
            className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-3 text-slate-100 text-xs outline-none transition"
            required
            disabled={isSuccess}
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">ยืนยันรหัสผ่าน (Confirm Password)</label>
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="ป้อนรหัสผ่านซ้ำอีกครั้ง"
            className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-3 text-slate-100 text-xs outline-none transition"
            required
            disabled={isSuccess}
          />
        </div>

        <div className="flex items-start gap-2.5 pt-2">
          <input
            type="checkbox"
            id="agreement"
            checked={agree}
            onChange={(e) => setAgree(e.target.checked)}
            className="mt-1 shrink-0 accent-indigo-600 rounded"
            disabled={isSuccess}
          />
          <label htmlFor="agreement" className="text-[11px] text-slate-400 leading-normal">
            ฉันขอยินยอมให้สโมสร Nexus Esports เข้าถึงสิทธิ์กล้องเว็บแคมเพื่อใช้ในการทดสอบทักษะ AR Reflex ของเกม Esports และยินดีต้อนรับการนำคะแนนไปอัปเดตบนตารางผู้นำสูงสุด (Leaderboard) แบบเรียลไทม์
          </label>
        </div>

        <button
          type="submit"
          disabled={isSuccess}
          className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3.5 rounded-xl text-xs uppercase tracking-wider transition shadow-lg shadow-indigo-600/10 flex justify-center items-center gap-1.5 cursor-pointer mt-2 disabled:opacity-50"
        >
          <UserPlus className="w-4 h-4" />
          ยืนยันและสร้างบัญชีผู้เล่น
        </button>
      </form>

      <div className="mt-6 text-center text-xs text-slate-400 pt-4 border-t border-slate-800/60">
        หากมีบัญชีอยู่แล้ว?{' '}
        <button
          onClick={() => onNavigate('home')}
          className="text-indigo-400 hover:text-indigo-300 font-bold underline cursor-pointer"
        >
          เข้าสู่ระบบคัดตัว
        </button>
      </div>
    </div>
  );
}
