import React, { useEffect, useRef, useState } from 'react';
import { Play, RotateCcw, Camera as CameraIcon, ShieldAlert, Award, Zap, Trophy, MousePointer } from 'lucide-react';
import { User } from '../types';

interface ArGameProps {
  currentUser: User;
  onUpdateHighScore: (score: number) => void;
  scoreboard: Array<{ username: string; score: number; date: string }>;
}

export default function ArGame({ currentUser, onUpdateHighScore, scoreboard }: ArGameProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30.0);
  const [gameEnded, setGameEnded] = useState(false);
  const [isNewRecord, setIsNewRecord] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');

  // กล้องและประเภทโหมดเล่น
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [playMode, setPlayMode] = useState<'ar' | 'mouse'>('ar'); // ar = ใช้กล้องจับการเคลื่อนไหว, mouse = ใช้เมาส์เลื่อนแตะ (สำหรับผู้ไม่มีกล้อง)

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const requestRef = useRef<number | null>(null);

  // ข้อมูลของดาวเป้าหมาย
  const [starTarget, setStarTarget] = useState<{ x: number; y: number; radius: number } | null>(null);
  
  // ใช้เก็บข้อมูลพิกเซลเฟรมที่แล้วเพื่อคำนวณการเคลื่อนไหว (Motion Detection)
  const prevFrameRef = useRef<ImageData | null>(null);
  const [isMotionTriggered, setIsMotionTriggered] = useState(false);

  // เริ่มต้นตั้งค่ากล้องเว็บแคม
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 640, height: 480, facingMode: 'user' }
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
          setIsCameraActive(true);
          setPlayMode('ar');
        }
      } else {
        throw new Error('เบราว์เซอร์ไม่รองรับการใช้งานกล้องในหน้านี้ (กรุณาลองเปิดด้วย HTTPS หรือแท็บใหม่)');
      }
    } catch (err: any) {
      console.error('Camera access error:', err);
      setCameraError(err.message || 'ไม่สามารถเข้าถึงกล้องเว็บแคมได้');
      setPlayMode('mouse'); // สลับไปใช้เมาส์อัตโนมัติ
    }
  };

  // ปิดกล้องเว็บแคม
  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  // ดำเนินการเปิดกล้องเมื่อหน้าโหลดในโหมด AR
  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, []);

  // สุ่มพิกัดดาวดวงใหม่บน Canvas
  const spawnStar = (canvasWidth: number, canvasHeight: number) => {
    const radius = 24;
    // หลีกเลี่ยงขอบเกินไป
    const x = Math.random() * (canvasWidth - radius * 4) + radius * 2;
    const y = Math.random() * (canvasHeight - radius * 4) + radius * 2;
    setStarTarget({ x, y, radius });
  };

  // เสียงบี๊บเก็บแต้ม (Web Audio API)
  const playScoreSound = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 โน้ต
      gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.12);
    } catch (e) {
      // ป้องกันข้อผิดพลาดกรณีบล็อกออดิโอ
    }
  };

  // เสียงหมดเวลา
  const playGameOverSound = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(220, audioCtx.currentTime); // ต่ำลง
      osc.frequency.exponentialRampToValueAtTime(110, audioCtx.currentTime + 0.5);
      gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.5);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.5);
    } catch (e) {}
  };

  // เริ่มเล่นเกมทดสอบ
  const startGame = () => {
    setScore(0);
    setTimeLeft(30.0);
    setGameEnded(false);
    setIsNewRecord(false);
    setSaveStatus('idle');
    setIsPlaying(true);
    
    const canvas = canvasRef.current;
    if (canvas) {
      spawnStar(canvas.width || 640, canvas.height || 480);
    } else {
      setStarTarget({ x: 320, y: 240, radius: 24 });
    }
  };

  // นาฬิกาจับเวลาถอยหลังถ้วนหน้า
  useEffect(() => {
    let timer: any;
    if (isPlaying && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 0.05) {
            clearInterval(timer);
            endGame();
            return 0;
          }
          return Math.round((prev - 0.05) * 100) / 100;
        });
      }, 50);
    }
    return () => clearInterval(timer);
  }, [isPlaying, timeLeft]);

  // จบการทดสอบ
  const endGame = () => {
    setIsPlaying(false);
    setGameEnded(true);
    playGameOverSound();
    
    // ตรวจสอบและบันทึกคะแนนสะสมแบบ Real-time (จำลอง AJAX API)
    setSaveStatus('saving');
    
    setTimeout(() => {
      let currentHigh = currentUser.highScore;
      const isNew = score > currentHigh;
      
      if (isNew) {
        setIsNewRecord(true);
        onUpdateHighScore(score);
        setSaveStatus('saved');
      } else {
        setSaveStatus('saved');
      }
    }, 1200);
  };

  // ฟังก์ชันวาดรูปดาว 5 แฉกบน Canvas
  const drawStarOnCanvas = (ctx: CanvasRenderingContext2D, cx: number, cy: number, spikes: number, outerRadius: number, innerRadius: number) => {
    let rot = Math.PI / 2 * 3;
    let x = cx;
    let y = cy;
    const step = Math.PI / spikes;

    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x, y);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#f59e0b';
    ctx.stroke();
    ctx.fillStyle = '#fbbf24';
    ctx.fill();
  };

  // แอนิเมชันลูปการวาดภาพและการทำ Motion Detection บน Canvas
  const renderLoop = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // เคลียร์ Canvas ก่อน
    ctx.clearRect(0, 0, width, height);

    if (playMode === 'ar' && isCameraActive && video && video.readyState >= 2) {
      // 1. วาดวิดีโอสดลง Canvas แบบกระจกเงา (Mirror)
      ctx.save();
      ctx.translate(width, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(video, 0, 0, width, height);
      ctx.restore();

      // 2. ทำการคำนวณการตรวจจับการเคลื่อนไหว (Webcam Motion Detection) บริเวณจุดดาวเป้าหมาย
      if (isPlaying && starTarget) {
        const starX = starTarget.x;
        const starY = starTarget.y;
        const checkSize = starTarget.radius * 2; // ขนาดขอบเขตตรวจจับ
        
        // ดึงข้อมูลภาพ ณ พื้นที่ของดาว
        try {
          // ดึงพิกเซลจากบริเวณรอบดาว
          const startX = Math.max(0, Math.min(width - checkSize, starX - checkSize / 2));
          const startY = Math.max(0, Math.min(height - checkSize, starY - checkSize / 2));
          const currentFrame = ctx.getImageData(startX, startY, checkSize, checkSize);
          
          if (prevFrameRef.current && prevFrameRef.current.width === checkSize && prevFrameRef.current.height === checkSize) {
            const currentPixels = currentFrame.data;
            const prevPixels = prevFrameRef.current.data;
            
            let changedPixelsCount = 0;
            const threshold = 40; // ระดับความแตกต่างสีที่จะนับว่าเคลื่อนไหว
            
            // วิ่งเช็กพิกเซลทีละเม็ดเปรียบเทียบเฟรมเก่าและเฟรมใหม่
            for (let i = 0; i < currentPixels.length; i += 4) {
              const rDiff = Math.abs(currentPixels[i] - prevPixels[i]);
              const gDiff = Math.abs(currentPixels[i+1] - prevPixels[i+1]);
              const bDiff = Math.abs(currentPixels[i+2] - prevPixels[i+2]);
              
              if ((rDiff + gDiff + bDiff) / 3 > threshold) {
                changedPixelsCount++;
              }
            }

            // คิดเป็นเปอร์เซ็นต์ความเปลี่ยนแปลงในบริเวณดาว
            const totalPixels = currentPixels.length / 4;
            const changePercent = (changedPixelsCount / totalPixels) * 100;

            // หากมีการเคลื่อนไหวเกิน 12% ถือว่าเอามือแตะดาว!
            if (changePercent > 12) {
              setIsMotionTriggered(true);
              playScoreSound();
              setScore(s => s + 1);
              spawnStar(width, height);
              prevFrameRef.current = null; // รีเซ็ตเฟรมเก่า
            } else {
              setIsMotionTriggered(false);
              prevFrameRef.current = currentFrame;
            }
          } else {
            prevFrameRef.current = currentFrame;
          }

          // วาดกรอบสแกนไฮเทครอบดาว
          ctx.strokeStyle = isMotionTriggered ? '#10b981' : '#06b6d4';
          ctx.lineWidth = 2;
          ctx.setLineDash([4, 4]);
          ctx.strokeRect(startX, startY, checkSize, checkSize);
          ctx.setLineDash([]);
          
          // ตัวหนังสือบอกสถานะสแกนมือ
          ctx.fillStyle = isMotionTriggered ? '#10b981' : '#06b6d4';
          ctx.font = '10px monospace';
          ctx.fillText(isMotionTriggered ? 'TOUCH DETECTED' : 'AR HAND SCANNING', startX, startY - 4);

        } catch (e) {
          // ป้องกันข้อผิดพลาดด้าน Security sandbox บางประเภท
        }
      }
    } else {
      // โหมดไม่มีกล้อง (วาดฉากหลังอวกาศ/เกมมิ่งแทนเว็บแคม)
      ctx.fillStyle = '#020617';
      ctx.fillRect(0, 0, width, height);

      // วาดวงกลมสะท้อนคลื่นเนบิวลาตกแต่งฉากหลัง
      ctx.fillStyle = '#1e1b4b';
      ctx.beginPath();
      ctx.arc(width / 2, height / 2, 120, 0, 2 * Math.PI);
      ctx.fill();

      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.arc(width / 2, height / 2, 80, 0, 2 * Math.PI);
      ctx.fill();

      // วาดเส้นตารางเรดาร์
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 1;
      for (let i = 0; i < width; i += 40) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, height);
        ctx.stroke();
      }
      for (let j = 0; j < height; j += 40) {
        ctx.beginPath();
        ctx.moveTo(0, j);
        ctx.lineTo(width, j);
        ctx.stroke();
      }

      ctx.fillStyle = '#475569';
      ctx.font = '12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('MOUSE GAMEPLAY MODE ACTIVE', width / 2, height - 20);
    }

    // 3. วาดดาวเป้าหมาย (สีทองสะท้อนแสง)
    if (isPlaying && starTarget) {
      drawStarOnCanvas(ctx, starTarget.x, starTarget.y, 5, starTarget.radius, starTarget.radius / 2.2);

      // วาดวงแหวนรอบดาวเสริมความโดดเด่น
      ctx.strokeStyle = 'rgba(251, 191, 36, 0.4)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(starTarget.x, starTarget.y, starTarget.radius + 8 + Math.sin(Date.now() / 150) * 4, 0, 2 * Math.PI);
      ctx.stroke();
    }

    // ทำงานแอนิเมชันเฟรมต่อไป
    requestRef.current = requestAnimationFrame(renderLoop);
  };

  // คอยอัปเดตแอนิเมชันลูปการวาด
  useEffect(() => {
    requestRef.current = requestAnimationFrame(renderLoop);
    return () => {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, [isPlaying, starTarget, isCameraActive, playMode]);

  // การสัมผัสสำหรับโหมดใช้เมาส์คลิก/แตะดาว
  const handleCanvasClickOrTouch = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isPlaying || !starTarget || !canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    // คำนวณอัตราส่วนพิกเซลจริงเทียบขนาดหน้าจอ
    const scaleX = canvasRef.current.width / rect.width;
    const scaleY = canvasRef.current.height / rect.height;

    const clickX = (e.clientX - rect.left) * scaleX;
    const clickY = (e.clientY - rect.top) * scaleY;

    // คำนวณระยะห่างระหว่างจุดคลิกและจุดศูนย์กลางดาว
    const dx = clickX - starTarget.x;
    const dy = clickY - starTarget.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    // ถ้ารัศมีไม่เกิน 40 พิกเซล (แตะโดน)
    if (distance < (starTarget.radius + 15)) {
      playScoreSound();
      setScore(s => s + 1);
      spawnStar(canvasRef.current.width, canvasRef.current.height);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 w-full">
      {/* ฝั่งซ้าย: แถบข้อมูลและกระดานคะแนน */}
      <div className="space-y-6 lg:col-span-1">
        
        {/* รายละเอียดการทำแบบทดสอบ */}
        <div id="ar-instructions-panel" className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md">
          <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <span className="text-xl">🦾</span> วิธีทดสอบความไวการตอบสนอง
          </h2>
          
          <div className="space-y-4 text-xs text-slate-400">
            <div className="flex gap-2 items-start">
              <span className="bg-cyan-950 text-cyan-400 font-mono w-5 h-5 rounded-full flex items-center justify-center shrink-0">1</span>
              <p>
                <strong className="text-slate-200">เลือกโหมดเล่น:</strong> แนะนำเปิดใช้งานกล้อง <span className="text-cyan-400 font-semibold">AR Camera Mode</span> เพื่อสัมผัสระบบเคลื่อนไหวจริง หรือสลับใช้ <span className="text-slate-300 font-semibold">Mouse/Touch Mode</span>
              </p>
            </div>
            
            <div className="flex gap-2 items-start">
              <span className="bg-cyan-950 text-cyan-400 font-mono w-5 h-5 rounded-full flex items-center justify-center shrink-0">2</span>
              <p>
                <strong className="text-slate-200">สแกนการแตะ:</strong> ในโหมดกล้อง ให้เลื่อน <strong class="text-slate-200">มือหรือใบหน้า</strong> เข้ามาปัดโบกทับ <span className="text-yellow-400 font-semibold">⭐ ดาวสีเหลือง</span> ที่เกิดบนหน้าจอ
              </p>
            </div>

            <div className="flex gap-2 items-start">
              <span className="bg-cyan-950 text-cyan-400 font-mono w-5 h-5 rounded-full flex items-center justify-center shrink-0">3</span>
              <p>
                <strong className="text-slate-200">ความปลอดภัยของข้อมูล:</strong> เมื่อครบกำหนด <strong class="text-amber-400">30 วินาที</strong> ระบบจะยิงคะแนนอัปโหลดบันทึกในฐานข้อมูลของไอดีท่านทันทีผ่าน Fetch API
              </p>
            </div>
          </div>

          {/* สลับการทำงานของโหมด */}
          <div className="mt-6 pt-5 border-t border-slate-800 flex flex-col gap-2">
            <span className="text-xs text-slate-500 font-medium mb-1 block">ตัวเลือกปรับแต่งควบคุม</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                id="btn-switch-ar"
                onClick={() => {
                  setPlayMode('ar');
                  startCamera();
                }}
                className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 border transition ${
                  playMode === 'ar'
                    ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/50'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                <CameraIcon className="w-3.5 h-3.5" />
                AR Camera
              </button>
              <button
                id="btn-switch-mouse"
                onClick={() => {
                  setPlayMode('mouse');
                  stopCamera();
                }}
                className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 border transition ${
                  playMode === 'mouse'
                    ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/50'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                <MousePointer className="w-3.5 h-3.5" />
                Mouse/Touch
              </button>
            </div>
          </div>
        </div>

        {/* บล็อกคะแนนสถิติ */}
        <div id="stats-panel" className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md space-y-4">
          <h3 className="text-xs text-slate-500 font-bold uppercase tracking-wider">คะแนนแบบเรียลไทม์ (REAL-TIME STATS)</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl text-center">
              <span className="text-slate-500 text-[10px] uppercase font-bold block mb-1">สถิติสูงสุดของคุณ</span>
              <div className="flex justify-center items-center gap-1 text-cyan-400">
                <Trophy className="w-4 h-4" />
                <span className="text-2xl font-black font-mono leading-none">{currentUser.highScore}</span>
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl text-center">
              <span className="text-slate-500 text-[10px] uppercase font-bold block mb-1">แต้มรอบนี้</span>
              <div className="flex justify-center items-center gap-1 text-yellow-400">
                <Zap className="w-4 h-4 animate-pulse" />
                <span className="text-2xl font-black font-mono leading-none">{score}</span>
              </div>
            </div>
          </div>

          {/* แถบรายงานสถานะอัปเดตลง SQL แบบ Real-time */}
          <div className="bg-slate-950/50 rounded-lg p-3 text-[11px] text-slate-500 border border-slate-800 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <span className={`w-1.5 h-1.5 rounded-full ${isCameraActive ? 'bg-emerald-500 animate-pulse' : 'bg-slate-600'}`}></span>
              {isCameraActive ? 'Camera Connected' : 'Camera Disconnected'}
            </span>
            <span className="font-mono text-slate-400">AJAX Status: READY</span>
          </div>

          {!isPlaying && (
            <button
              id="btn-trigger-test"
              onClick={startGame}
              className="w-full bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold py-3.5 rounded-xl transition shadow-lg shadow-emerald-950/20 text-center flex justify-center items-center gap-2 cursor-pointer text-sm"
            >
              <Play className="w-4 h-4" />
              เริ่มต้นแบบทดสอบ (30 วินาที)
            </button>
          )}
        </div>

        {/* ตารางคะแนนผู้สมัครที่มีคะแนนสูงสูด */}
        <div id="leaderboard-panel" className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-yellow-500" />
              Nexus Top Candidates
            </h4>
            <span className="text-[10px] bg-slate-950 px-2 py-0.5 rounded text-indigo-400 font-mono">Live</span>
          </div>

          <div className="space-y-2">
            {scoreboard.length === 0 ? (
              <p className="text-center text-xs text-slate-600 py-4">ยังไม่มีสถิติกดทดสอบคะแนนสูงสุดในขณะนี้</p>
            ) : (
              scoreboard
                .sort((a, b) => b.score - a.score)
                .slice(0, 5)
                .map((item, index) => (
                  <div
                    key={index}
                    className={`flex justify-between items-center px-3 py-2 rounded-lg text-xs border ${
                      item.username === currentUser.username
                        ? 'bg-indigo-950/30 border-indigo-500/40'
                        : 'bg-slate-950/60 border-slate-800/80'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold ${
                        index === 0 ? 'bg-yellow-500/20 text-yellow-500 text-[10px]' :
                        index === 1 ? 'bg-slate-300/20 text-slate-300 text-[10px]' :
                        index === 2 ? 'bg-amber-600/20 text-amber-600 text-[10px]' :
                        'bg-slate-800 text-slate-500 text-[9px]'
                      }`}>
                        {index + 1}
                      </span>
                      <span className="font-semibold text-slate-200">
                        @{item.username} {item.username === currentUser.username && '(คุณ)'}
                      </span>
                    </div>
                    <span className="font-mono font-bold text-white bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                      {item.score}
                    </span>
                  </div>
                ))
            )}
          </div>
        </div>

      </div>

      {/* ฝั่งขวา: หน้าจอเว็บแคม AR Play Area */}
      <div className="lg:col-span-2 space-y-4">
        
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden p-4 relative shadow-2xl">
          {/* แถบควบคุมบน Area */}
          <div className="flex justify-between items-center mb-3">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${isPlaying ? 'bg-red-500 animate-pulse' : 'bg-slate-600'}`}></span>
              <span className="text-xs text-slate-400 font-mono uppercase tracking-wider">
                {playMode === 'ar' ? 'LIVE FEED: AR HAND TRACKING' : 'SCREEN AREA: CLICK TO TEST'}
              </span>
            </div>
            <div className="bg-slate-950 px-3 py-1 rounded-full border border-slate-800 font-mono text-xs flex gap-1.5 items-center">
              <span className="text-slate-500">เวลาเหลือ:</span>
              <span id="ar-game-timer" className={`font-black text-sm ${timeLeft < 10 ? 'text-red-500 animate-pulse' : 'text-cyan-400'}`}>
                {timeLeft.toFixed(2)}
              </span>
              <span className="text-slate-500">วิ</span>
            </div>
          </div>

          {/* หน้าจอหลักของการเล่น */}
          <div className="relative w-full aspect-video bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center">
            
            {/* ซ่อนภาพวิดีโอหลักเพื่อวาดผ่าน Canvas แทน */}
            <video
              ref={videoRef}
              id="ar-game-video"
              className="hidden"
              playsInline
              muted
            />

            {/* Canvas วาดผลงาน AR และเกมเพลย์ */}
            <canvas
              ref={canvasRef}
              id="ar-game-canvas"
              width={640}
              height={480}
              onClick={handleCanvasClickOrTouch}
              className={`w-full h-full object-cover ${isPlaying ? 'cursor-crosshair' : 'cursor-default'}`}
            />

            {/* บล็อกแจ้งเตือนสถานะเว็บแคม หากติดขัดสิทธิ์หรือขัดข้อง */}
            {playMode === 'ar' && !isCameraActive && (
              <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-sm flex flex-col justify-center items-center text-center p-6 gap-4">
                <div className="p-3 bg-red-950/40 rounded-full text-red-500 border border-red-900/50">
                  <ShieldAlert className="w-8 h-8" />
                </div>
                <div className="max-w-md">
                  <p className="font-bold text-slate-200">ไม่สามารถเชื่อมต่อเว็บแคมได้ในเบราว์เซอร์นี้</p>
                  <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                    เนื่องจากความปลอดภัยของเฟรมและสิทธิ์เบราว์เซอร์ กรุณากดปุ่มเปิดกล้อง หรือสลับไปใช้ <strong className="text-slate-300 font-semibold">Mouse/Touch Mode (ใช้เมาส์แตะ)</strong> เพื่อสัมผัสฟังก์ชันแบบทดสอบและการบันทึกข้อมูลแบบเรียลไทม์
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    id="btn-retry-camera"
                    onClick={startCamera}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs px-4 py-2 rounded-lg font-medium transition"
                  >
                    เปิดกล้องอีกครั้ง
                  </button>
                  <button
                    id="btn-fallback-mouse"
                    onClick={() => {
                      setPlayMode('mouse');
                      setCameraError(null);
                    }}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-4 py-2 rounded-lg font-medium transition"
                  >
                    เล่นโดยใช้เมาส์ (Mouse Mode)
                  </button>
                </div>
              </div>
            )}

            {/* แสดงคำแนะนำก่อนกดเริ่มเล่น */}
            {!isPlaying && !gameEnded && (
              <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs flex flex-col justify-center items-center gap-4 text-center p-6">
                <div className="w-16 h-16 rounded-full bg-indigo-900/40 text-indigo-400 border border-indigo-700/50 flex items-center justify-center text-2xl font-bold animate-bounce shadow-lg">
                  🎮
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">แบบทดสอบปฏิกิริยา Esports AR</h3>
                  <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto leading-relaxed">
                    ระบบจะเปิดกล้องแล้วสุ่มสร้างดาวสีทองขึ้นมาบนจอ เพื่อจับความเร็วมือของคุณในการปัดแตะเป้าหมาย
                  </p>
                </div>
                <button
                  id="btn-overlay-start"
                  onClick={startGame}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-6 py-2.5 rounded-xl text-sm transition shadow-lg shadow-indigo-600/30"
                >
                  เริ่มการคัดตัว
                </button>
              </div>
            )}

            {/* ป๊อปอัปแจ้งผลการเล่นเมื่อหมดเวลา และบันทึกคะแนนสะสม */}
            {gameEnded && (
              <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-md flex flex-col justify-center items-center gap-4 text-center p-6">
                <span className="text-5xl">🏆</span>
                <div className="max-w-xs space-y-2">
                  <h3 className="text-xl font-bold text-white">หมดเวลาคัดตัว!</h3>
                  <p className="text-xs text-slate-400">
                    ความเร็วและคะแนนในรอบนี้ของคุณคือ:
                  </p>
                  <div className="bg-slate-900 border border-slate-800 py-3 rounded-xl">
                    <span className="text-4xl font-black font-mono text-yellow-400">{score}</span>
                    <span className="text-slate-500 text-xs ml-1">คะแนน</span>
                  </div>
                  
                  {isNewRecord && (
                    <p className="text-xs text-emerald-400 font-bold animate-pulse flex items-center justify-center gap-1.5">
                      🔥 ยินดีด้วย! ทำสถิติใหม่ของตัวคุณสำเร็จ!
                    </p>
                  )}

                  {/* รายงานสถานะ AJAX เสมือน */}
                  <div className="pt-2">
                    {saveStatus === 'saving' && (
                      <p className="text-xs text-slate-400 flex items-center gap-1.5 justify-center">
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping"></span>
                        กำลังส่งคะแนน SQL ด้วย Fetch API...
                      </p>
                    )}
                    {saveStatus === 'saved' && (
                      <p className="text-[11px] text-indigo-400 bg-indigo-950/50 px-3 py-1.5 rounded-lg border border-indigo-900/30 inline-block">
                        💾 บันทึกลงฐานข้อมูล MySQL ตาราง <code className="bg-slate-900 px-1 py-0.5 rounded text-white font-mono text-[9px]">users</code> (id: {currentUser.username}) สำเร็จแบบ Real-time
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex gap-3 pt-3">
                  <button
                    id="btn-retry-test"
                    onClick={startGame}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-6 py-2.5 rounded-lg text-xs transition flex items-center gap-1.5"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    คัดตัวอีกครั้ง
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>

        {/* แนะนำเพิ่มเติม */}
        <div className="bg-indigo-950/20 border border-indigo-900/50 p-4 rounded-xl flex gap-3 items-center text-slate-400 text-xs">
          <span className="text-indigo-400 text-lg">💡</span>
          <p>
            <strong>คำแนะนำเกี่ยวกับเทคโนโลยีกล้อง AR:</strong> หากเบราว์เซอร์หรืออุปกรณ์ของคุณไม่พร้อมใช้งานเว็บแคม โปรแกรมเว็บไซด์ที่คุณดาวน์โหลดจาก <span className="text-white font-semibold">"ศูนย์โค้ดส่งออก XAMPP"</span> จะทำการโหลดไลบรารีปัญญาประดิษฐ์จากไลบรารี <strong className="text-slate-300 font-semibold">MediaPipe Hands</strong> จากระยะไกลได้ทันทีโดยอัตโนมัติเมื่อรันในเครื่องเซิร์ฟเวอร์จำลองของคุณ!
          </p>
        </div>

      </div>
    </div>
  );
}
