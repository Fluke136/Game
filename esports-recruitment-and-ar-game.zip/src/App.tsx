/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { ActiveView, User, GameScore } from './types';
import InfoHome from './components/InfoHome';
import RegisterForm from './components/RegisterForm';
import ArGame from './components/ArGame';
import CodeViewer from './components/CodeViewer';
import { Target, HardDrive, LogOut, Terminal, Users, UserCheck } from 'lucide-react';

export default function App() {
  const [activeView, setActiveView] = useState<ActiveView>('home');
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [scoreboard, setScoreboard] = useState<GameScore[]>([]);
  const [successMessage, setSuccessMessage] = useState<string>('');

  // 1. โหลดข้อมูลจำลองเมื่อเริ่มต้นเปิดเว็บ (Seed Data)
  useEffect(() => {
    // โหลดผู้ใช้ทั้งหมดจาก LocalStorage (จำลอง MySQL บนบราวเซอร์)
    const storedUsers = localStorage.getItem('esports_users');
    let loadedUsers: User[] = [];
    
    if (storedUsers) {
      loadedUsers = JSON.parse(storedUsers);
    } else {
      // ผู้ใช้เริ่มต้นที่แถมให้เพื่อความรวดเร็วในการทดสอบระบบ
      loadedUsers = [
        {
          username: 'admin',
          passwordHash: '123456',
          highScore: 28,
          registeredAt: new Date().toISOString()
        },
        {
          username: 'cyber_reflex_th',
          passwordHash: 'password',
          highScore: 35,
          registeredAt: new Date().toISOString()
        },
        {
          username: 'pro_aim_master',
          passwordHash: 'password',
          highScore: 42,
          registeredAt: new Date().toISOString()
        }
      ];
      localStorage.setItem('esports_users', JSON.stringify(loadedUsers));
    }
    setUsers(loadedUsers);

    // โหลดผู้ใช้ที่ล็อกอินค้างอยู่
    const storedCurrentUser = localStorage.getItem('esports_current_user');
    if (storedCurrentUser) {
      setCurrentUser(JSON.parse(storedCurrentUser));
    }

    // โหลดตารางคะแนนสูงสุด (Scoreboard)
    const storedScoreboard = localStorage.getItem('esports_scoreboard');
    if (storedScoreboard) {
      setScoreboard(JSON.parse(storedScoreboard));
    } else {
      // อันดับคะแนนจำลองสุดตื่นตาตื่นใจของสโมสร
      const defaultScores: GameScore[] = [
        { username: 'pro_aim_master', score: 42, date: '2026-07-01' },
        { username: 'cyber_reflex_th', score: 35, date: '2026-07-05' },
        { username: 'admin', score: 28, date: '2026-07-09' },
        { username: 'skyler_aim', score: 24, date: '2026-07-10' }
      ];
      localStorage.setItem('esports_scoreboard', JSON.stringify(defaultScores));
      setScoreboard(defaultScores);
    }
  }, []);

  // 2. ฟังก์ชันสมัครสมาชิกจำลอง (register.php)
  const handleRegister = (username: string, passwordHash: string): { success: boolean; message: string } => {
    // เช็กว่าไอดีซ้ำหรือไม่
    const userExists = users.some(u => u.username.toLowerCase() === username.toLowerCase());
    if (userExists) {
      return { success: false, message: 'ชื่อผู้ใช้งานนี้มีผู้ใช้ไปแล้ว กรุณาเลือกชื่ออื่น!' };
    }

    const newUser: User = {
      username,
      passwordHash, // ในทางปฏิบัติจะเข้ารหัสลับ ในแบบจำลองเราเก็บค่าตรงเพื่อความเรียบง่าย
      highScore: 0,
      registeredAt: new Date().toISOString()
    };

    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    localStorage.setItem('esports_users', JSON.stringify(updatedUsers));

    // เพิ่มชื่อผู้ใช้และคะแนนเริ่มต้นลงตารางบอร์ด
    const updatedScoreboard = [...scoreboard, { username, score: 0, date: new Date().toISOString().split('T')[0] }];
    setScoreboard(updatedScoreboard);
    localStorage.setItem('esports_scoreboard', JSON.stringify(updatedScoreboard));

    setSuccessMessage('สมัครสมาชิกสำเร็จเรียบร้อย! คุณสามารถใช้ชื่อผู้ใช้และรหัสผ่านล็อกอินเข้าเล่นเกม AR ได้ทันที');
    return { success: true, message: 'สมัครสำเร็จ!' };
  };

  // 3. ฟังก์ชันล็อกอินจำลอง (index.php)
  const handleLogin = (username: string, passwordHash: string): boolean => {
    const user = users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.passwordHash === passwordHash);
    if (user) {
      setCurrentUser(user);
      localStorage.setItem('esports_current_user', JSON.stringify(user));
      setSuccessMessage(''); // รีเซ็ตข้อความสมัครสมาชิกสำเร็จ
      setActiveView('game'); // ส่งไปหน้าเล่นเกม AR ทันที
      return true;
    }
    return false;
  };

  // 4. ฟังก์ชันออกจากระบบ (logout.php)
  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('esports_current_user');
    setActiveView('home');
  };

  // 5. อัปเดตคะแนนสูงสุดแบบ Real-time ลงฐานข้อมูลจำลอง (update_score.php)
  const handleUpdateHighScore = (newScore: number) => {
    if (!currentUser) return;

    // อัปเดตข้อมูลของผู้ใช้
    const updatedUsers = users.map(u => {
      if (u.username === currentUser.username) {
        return { ...u, highScore: newScore };
      }
      return u;
    });
    setUsers(updatedUsers);
    localStorage.setItem('esports_users', JSON.stringify(updatedUsers));

    // อัปเดตตารางบอร์ดกระดานคะแนนผู้นำ
    let scoreUpdated = false;
    const updatedScoreboard = scoreboard.map(item => {
      if (item.username === currentUser.username) {
        scoreUpdated = true;
        return { ...item, score: Math.max(item.score, newScore), date: new Date().toISOString().split('T')[0] };
      }
      return item;
    });

    // หากยังไม่มีในกระดาน ให้เพิ่มใหม่
    const finalScoreboard = scoreUpdated 
      ? updatedScoreboard 
      : [...updatedScoreboard, { username: currentUser.username, score: newScore, date: new Date().toISOString().split('T')[0] }];

    setScoreboard(finalScoreboard);
    localStorage.setItem('esports_scoreboard', JSON.stringify(finalScoreboard));

    // อัปเดต session ปัจจุบัน
    const updatedCurrentUser = { ...currentUser, highScore: Math.max(currentUser.highScore, newScore) };
    setCurrentUser(updatedCurrentUser);
    localStorage.setItem('esports_current_user', JSON.stringify(updatedCurrentUser));
  };

  return (
    <div className="bg-slate-950 text-slate-100 min-h-screen flex flex-col justify-between selection:bg-indigo-500 selection:text-white">
      
      {/* ส่วนหัวของแอปพลิเคชัน (Header) */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          
          {/* โลโก้แบรนด์สโมสร */}
          <div 
            onClick={() => setActiveView('home')} 
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center font-bold text-white text-lg shadow-lg shadow-indigo-600/20 group-hover:scale-105 transition duration-200">
              N
            </div>
            <span className="text-xl font-black tracking-wider bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-500 bg-clip-text text-transparent">
              NEXUS ESPORTS
            </span>
          </div>

          {/* แถบนำทางความเร็ว (Navigation) */}
          <div className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => setActiveView('home')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeView === 'home' || activeView === 'register'
                  ? 'bg-indigo-600/20 text-indigo-300'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              รับสมัคร / เข้าสู่ระบบ
            </button>
            
            <button
              onClick={() => {
                if (currentUser) {
                  setActiveView('game');
                } else {
                  alert('กรุณาล็อกอินเพื่อใช้ทำแบบทดสอบ AR Game!');
                }
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1 ${
                activeView === 'game'
                  ? 'bg-indigo-600/20 text-indigo-300'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Target className="w-3.5 h-3.5" />
              AR Reflex Game
            </button>

            <button
              onClick={() => setActiveView('export')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1 ${
                activeView === 'export'
                  ? 'bg-indigo-600/20 text-indigo-300'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <HardDrive className="w-3.5 h-3.5" />
              ดาวน์โหลดซอร์สโค้ด XAMPP
            </button>
          </div>

          {/* โปรไฟล์ผู้ใช้ล็อกอิน (User Session Badge) */}
          <div className="flex items-center gap-3">
            {currentUser ? (
              <div className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 flex items-center gap-3">
                <div className="flex items-center gap-1.5 text-xs">
                  <UserCheck className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
                  <span className="font-semibold text-slate-200">@{currentUser.username}</span>
                  <span className="text-slate-500">|</span>
                  <span className="text-slate-400 text-[11px]">Best: <strong className="text-cyan-400 font-mono">{currentUser.highScore}</strong></span>
                </div>
                <button
                  onClick={handleLogout}
                  title="ออกจากระบบ"
                  className="p-1 bg-slate-950 hover:bg-red-950 text-slate-400 hover:text-red-400 rounded transition cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <div className="text-xs text-slate-500 font-medium">
                Guest Mode
              </div>
            )}
          </div>

        </div>
      </header>

      {/* บล็อกพายูสและเนื้อหาหลัก (Main Content) */}
      <main className="max-w-6xl w-full mx-auto px-4 py-12 flex-grow flex items-center justify-center">
        {activeView === 'home' && (
          <InfoHome
            onLogin={handleLogin}
            onNavigate={setActiveView}
            successMessage={successMessage}
          />
        )}

        {activeView === 'register' && (
          <RegisterForm
            onRegister={handleRegister}
            onNavigate={setActiveView}
          />
        )}

        {activeView === 'game' && currentUser && (
          <ArGame
            currentUser={currentUser}
            onUpdateHighScore={handleUpdateHighScore}
            scoreboard={scoreboard}
          />
        )}

        {activeView === 'export' && (
          <div className="w-full space-y-6">
            <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 space-y-3">
              <h2 className="text-xl font-black text-white flex items-center gap-2">
                <Terminal className="w-5 h-5 text-indigo-400" />
                ศูนย์แจกโค้ด PHP & MySQL สำหรับรันบน XAMPP
              </h2>
              <p className="text-slate-400 text-xs sm:text-sm leading-relaxed max-w-3xl">
                เนื่องจากแพลตฟอร์มพรีวิวนี้รันบนเซิร์ฟเวอร์ระบบ <strong className="text-slate-200">Node.js (Vite + React)</strong> ทางเราได้จัดเตรียมชุดคำสั่งซอร์สโค้ด <strong className="text-slate-200">PHP 100% พร้อมฐานข้อมูล MySQL</strong> สำหรับนำไปคัดลอกเปิดโปรแกรมใช้งานบน XAMPP ได้ตามโจทย์อย่างเป๊ะๆ ครบถ้วนทุกความปลอดภัย!
              </p>
            </div>
            <CodeViewer />
          </div>
        )}
      </main>

      {/* แถบแสดงเครดิตล่างสุด (Footer) */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-center text-xs text-slate-500 space-y-2">
        <p>&copy; 2026 Nexus Esports Recruitment Campaign & reflex training software. Developed for educational demonstration.</p>
        <p className="text-[10px] text-slate-600 font-mono">Server Status: online | Node.js Runtime Platform</p>
      </footer>

    </div>
  );
}
