export interface User {
  username: string;
  passwordHash: string; // Stored in localstorage for our simulator
  highScore: number;
  registeredAt: string;
}

export interface GameScore {
  username: string;
  score: number;
  date: string;
}

export type ActiveView = 'home' | 'register' | 'game' | 'export';
