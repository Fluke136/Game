export interface PHPFile {
  filename: string;
  description: string;
  language: 'php' | 'sql' | 'markdown';
  content: string;
}

export const xamppProjectFiles: PHPFile[] = [
  {
    filename: 'database.sql',
    description: 'คำสั่ง SQL สำหรับสร้างฐานข้อมูลและตารางผู้ใช้งาน',
    language: 'sql',
    content: `-- 1. สร้างฐานข้อมูลสำหรับระบบรับสมัครและเล่นเกม
CREATE DATABASE IF NOT EXISTS esports_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE esports_db;

-- 2. สร้างตารางสำหรับเก็บข้อมูลผู้ใช้งาน (สมัครสมาชิก) และคะแนนสูงสุด
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    high_score INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
`
  },
  {
    filename: 'db_connect.php',
    description: 'ไฟล์เชื่อมต่อฐานข้อมูล MySQL ด้วย PDO',
    language: 'php',
    content: `<?php
// กำหนดตัวแปรสำหรับเชื่อมต่อ MySQL บน XAMPP (ค่าเริ่มต้น: user=root, password=ว่าง)
$host = "localhost";
$dbname = "esports_db";
$username = "root";
$password = "";

try {
    // เชื่อมต่อด้วย PDO เพื่อความปลอดภัยและการจัดการข้อผิดพลาดที่ดี
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("เชื่อมต่อฐานข้อมูลล้มเหลว: " . $e->getMessage());
}
?>`
  },
  {
    filename: 'index.php',
    description: 'หน้าแรกแสดงข้อมูลทีมอีสปอร์ต ฟอร์มล็อกอิน และลิงก์สมัครสมาชิก',
    language: 'php',
    content: `<?php
session_start();
require_once 'db_connect.php';

// หากล็อกอินอยู่แล้ว ให้ส่งไปหน้าเกมทันที
if (isset($_SESSION['user_id'])) {
    header("Location: game.php");
    exit();
}

$error = "";
$success = "";

// ตรวจสอบสถานะการสมัครสมาชิกเสร็จสิ้น
if (isset($_GET['registered']) && $_GET['registered'] == 'success') {
    $success = "สมัครสมาชิกสำเร็จ! กรุณาล็อกอินเพื่อเข้าสู่ระบบ";
}

// เมื่อมีการกดปุ่มล็อกอิน
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (!empty($username) && !empty($password)) {
        try {
            $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
            $stmt->execute(['username' => $username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // เก็บข้อมูลใน Session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['high_score'] = $user['high_score'];

                header("Location: game.php");
                exit();
            } else {
                $error = "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง!";
            }
        } catch (PDOException $e) {
            $error = "เกิดข้อผิดพลาด: " . $e->getMessage();
        }
    } else {
        $error = "กรุณากรอกข้อมูลให้ครบถ้วน!";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Esports Recruitment - ล็อกอินเข้าสู่ระบบ</title>
    <!-- ใช้ Tailwind CSS CDN สำหรับความสวยงามและทันสมัย -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Prompt', sans-serif; }
    </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen flex flex-col justify-between">

    <!-- Header / Navigation -->
    <header class="border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-50">
        <div class="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center gap-2">
                <span class="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-indigo-500 bg-clip-text text-transparent">NEXUS ESPORTS</span>
            </div>
            <div>
                <a href="register.php" class="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg font-medium transition duration-200">สมัครเข้าทีม</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-6xl mx-auto px-4 py-12 flex-grow grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        
        <!-- ข้อมูลจำลองเกี่ยวกับทีมอีสปอร์ต -->
        <div class="space-y-6">
            <span class="bg-indigo-900/50 text-indigo-300 border border-indigo-700/50 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider">Recruiting Season 2026</span>
            <h1 class="text-4xl md:text-5xl font-black tracking-tight leading-tight">
                ก้าวสู่การเป็นนักกีฬา <br>
                <span class="bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-500 bg-clip-text text-transparent">ระดับมืออาชีพ</span> กับเรา!
            </h1>
            <p class="text-slate-400 leading-relaxed text-base">
                Nexus Esports สโมสรอีสปอร์ตชั้นนำระดับเอเชีย กำลังเปิดรับสมัครผู้เล่นหน้าใหม่ที่มีความสามารถและปฏิกิริยาตอบสนองที่ว่องไวเพื่อเข้าร่วมแคมป์ฝึกซ้อมพิเศษประจำปี 2026
            </p>
            
            <div class="grid grid-cols-3 gap-4 pt-4">
                <div class="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                    <div class="text-2xl font-bold text-cyan-400">#1</div>
                    <div class="text-xs text-slate-400">Pro League Team</div>
                </div>
                <div class="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                    <div class="text-2xl font-bold text-indigo-400">24/7</div>
                    <div class="text-xs text-slate-400">Gaming Camp</div>
                </div>
                <div class="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                    <div class="text-2xl font-bold text-violet-400">100K+</div>
                    <div class="text-xs text-slate-400">Monthly Salary</div>
                </div>
            </div>

            <!-- ข้อกำหนดขั้นแรก -->
            <div class="p-4 bg-slate-900/40 rounded-xl border border-slate-800/80 flex items-start gap-3">
                <span class="text-xl">🎯</span>
                <p class="text-sm text-slate-400">
                    <strong class="text-slate-200">ภารกิจแรกของคุณ:</strong> สมัครสมาชิกและล็อกอินเข้าสู่ระบบ เพื่อทดสอบปฏิกิริยาความไว (Reflex Test) ด้วยเทคโนโลยี AR Hand-Tracking เพื่อพิสูจน์ฝีมือก่อนสมัครเข้าทีม!
                </p>
            </div>
        </div>

        <!-- ฟอร์มเข้าสู่ระบบ (Login) -->
        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-xl max-w-md w-full mx-auto">
            <h2 class="text-2xl font-bold mb-2">เข้าสู่ระบบคัดตัว</h2>
            <p class="text-slate-400 text-sm mb-6">กรอกข้อมูลบัญชีของคุณเพื่อทำแบบทดสอบ AR Game</p>

            <?php if (!empty($error)): ?>
                <div class="bg-red-900/50 border border-red-700 text-red-200 p-3 rounded-lg text-sm mb-4">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="bg-emerald-900/50 border border-emerald-700 text-emerald-200 p-3 rounded-lg text-sm mb-4">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <form action="index.php" method="POST" class="space-y-4">
                <div>
                    <label for="username" class="block text-sm font-medium text-slate-300 mb-1.5">ชื่อผู้ใช้งาน (Username)</label>
                    <input type="text" id="username" name="username" required 
                           class="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-lg px-4 py-2.5 text-slate-100 outline-none transition" 
                           placeholder="เช่น nexus_player">
                </div>

                <div>
                    <div class="flex justify-between items-center mb-1.5">
                        <label for="password" class="block text-sm font-medium text-slate-300">รหัสผ่าน (Password)</label>
                    </div>
                    <input type="password" id="password" name="password" required 
                           class="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-lg px-4 py-2.5 text-slate-100 outline-none transition" 
                           placeholder="••••••••">
                </div>

                <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-medium py-3 rounded-lg transition duration-200 mt-2 shadow-lg shadow-indigo-600/20">
                    เข้าสู่ระบบระบบคัดตัว
                </button>
            </form>

            <div class="mt-6 text-center text-sm text-slate-400">
                ยังไม่มีบัญชีใช่หรือไม่? <a href="register.php" class="text-indigo-400 hover:text-indigo-300 font-semibold underline">สมัครสมาชิกที่นี่</a>
            </div>
        </div>

    </main>

    <!-- Footer -->
    <footer class="border-t border-slate-900 bg-slate-950 py-6 text-center text-sm text-slate-500">
        <p>&copy; 2026 Nexus Esports Recruitment Program. All Rights Reserved.</p>
    </footer>

</body>
</html>`
  },
  {
    filename: 'register.php',
    description: 'หน้าแบบฟอร์มสมัครสมาชิกใหม่ เพื่อบันทึกชื่อผู้ใช้และรหัสผ่านลง MySQL',
    language: 'php',
    content: `<?php
session_start();
require_once 'db_connect.php';

// หากล็อกอินอยู่แล้ว ให้ส่งไปหน้าเกมทันที
if (isset($_SESSION['user_id'])) {
    header("Location: game.php");
    exit();
}

$error = "";

// เมื่อมีการส่งข้อมูลจากฟอร์มสมัครสมาชิก
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (!empty($username) && !empty($password) && !empty($confirm_password)) {
        
        // ตรวจสอบความถูกต้องเบื้องต้น
        if (strlen($username) < 4) {
            $error = "ชื่อผู้ใช้งานต้องมีความยาวอย่างน้อย 4 ตัวอักษร!";
        } elseif (strlen($password) < 6) {
            $error = "รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร!";
        } elseif ($password !== $confirm_password) {
            $error = "รหัสผ่านและการยืนยันรหัสผ่านไม่ตรงกัน!";
        } else {
            try {
                // ตรวจสอบว่าชื่อผู้ใช้นี้ซ้ำในฐานข้อมูลหรือไม่
                $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE username = :username");
                $stmt->execute(['username' => $username]);
                $userExists = $stmt->fetchColumn();

                if ($userExists) {
                    $error = "ชื่อผู้ใช้งานนี้มีผู้ใช้ไปแล้ว กรุณาเลือกชื่ออื่น!";
                } else {
                    // เข้ารหัสผ่านเพื่อความปลอดภัยสูง (Hash Password)
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                    // บันทึกลงฐานข้อมูล
                    $insert_stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (:username, :password)");
                    $insert_stmt->execute([
                        'username' => $username,
                        'password' => $hashed_password
                    ]);

                    // นำทางกลับหน้าแรกและแจ้งสถานะสำเร็จ
                    header("Location: index.php?registered=success");
                    exit();
                }
            } catch (PDOException $e) {
                $error = "เกิดข้อผิดพลาดในการบันทึกข้อมูล: " . $e->getMessage();
            }
        }
    } else {
        $error = "กรุณากรอกข้อมูลให้ครบถ้วน!";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Esports Recruitment - สมัครสมาชิกใหม่</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Prompt', sans-serif; }
    </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen flex flex-col justify-between">

    <!-- Header -->
    <header class="border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-50">
        <div class="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center gap-2">
                <span class="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-indigo-500 bg-clip-text text-transparent">NEXUS ESPORTS</span>
            </div>
            <div>
                <a href="index.php" class="text-slate-300 hover:text-white px-4 py-2 font-medium transition duration-200">กลับหน้าหลัก</a>
            </div>
        </div>
    </header>

    <!-- Main Form Content -->
    <main class="max-w-md w-full mx-auto px-4 py-12 flex-grow flex items-center justify-center">
        
        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-xl w-full">
            <h2 class="text-2xl font-bold mb-2 text-center">สมัครเข้าทีม Nexus</h2>
            <p class="text-slate-400 text-sm mb-6 text-center">สร้างบัญชีผู้เล่นสำหรับทำแบบทดสอบและบันทึกสถิติ</p>

            <?php if (!empty($error)): ?>
                <div class="bg-red-900/50 border border-red-700 text-red-200 p-3 rounded-lg text-sm mb-4">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form action="register.php" method="POST" class="space-y-4">
                <div>
                    <label for="username" class="block text-sm font-medium text-slate-300 mb-1.5">ชื่อผู้ใช้งาน (Username)</label>
                    <input type="text" id="username" name="username" required 
                           class="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-lg px-4 py-2.5 text-slate-100 outline-none transition" 
                           placeholder="ภาษาอังกฤษหรือตัวเลข 4 ตัวขึ้นไป">
                </div>

                <div>
                    <label for="password" class="block text-sm font-medium text-slate-300 mb-1.5">รหัสผ่าน (Password)</label>
                    <input type="password" id="password" name="password" required 
                           class="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-lg px-4 py-2.5 text-slate-100 outline-none transition" 
                           placeholder="ความยาวอย่างน้อย 6 ตัวอักษร">
                </div>

                <div>
                    <label for="confirm_password" class="block text-sm font-medium text-slate-300 mb-1.5">ยืนยันรหัสผ่าน (Confirm Password)</label>
                    <input type="password" id="confirm_password" name="confirm_password" required 
                           class="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-lg px-4 py-2.5 text-slate-100 outline-none transition" 
                           placeholder="กรอกรหัสผ่านเดิมซ้ำอีกครั้ง">
                </div>

                <div class="flex items-start gap-2 pt-2">
                    <input type="checkbox" id="terms" required class="mt-1 accent-indigo-600">
                    <label for="terms" class="text-xs text-slate-400">ฉันยอมรับเงื่อนไขในการเข้ารับการสแกนใบหน้า/มือ และทดสอบปฏิกิริยาเพื่อเก็บประวัติในสโมสร Nexus Esports</label>
                </div>

                <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-medium py-3 rounded-lg transition duration-200 mt-4 shadow-lg shadow-indigo-600/20">
                    ยืนยันสมัครสมาชิก
                </button>
            </form>

            <div class="mt-6 text-center text-sm text-slate-400">
                มีบัญชีอยู่แล้ว? <a href="index.php" class="text-indigo-400 hover:text-indigo-300 font-semibold underline">เข้าสู่ระบบที่นี่</a>
            </div>
        </div>

    </main>

    <!-- Footer -->
    <footer class="border-t border-slate-900 bg-slate-950 py-6 text-center text-sm text-slate-500">
        <p>&copy; 2026 Nexus Esports Recruitment Program. All Rights Reserved.</p>
    </footer>

</body>
</html>`
  },
  {
    filename: 'game.php',
    description: 'หน้าเกม AR ทดสอบความเร็วในการตอบสนอง ใช้กล้องเว็บแคมและ MediaPipe Hands ในการจับมือจับดาว',
    language: 'php',
    content: `<?php
session_start();
require_once 'db_connect.php';

// บังคับล็อกอิน หากยังไม่ได้ล็อกอิน ให้ส่งกลับหน้าแรก
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// ดึงคะแนนสูงสุดล่าสุดจากฐานข้อมูล
try {
    $stmt = $conn->prepare("SELECT high_score FROM users WHERE id = :id");
    $stmt->execute(['id' => $user_id]);
    $high_score = $stmt->fetchColumn();
    $_SESSION['high_score'] = $high_score; // อัปเดตใน session
} catch (PDOException $e) {
    $high_score = $_SESSION['high_score'] ?? 0;
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nexus Reflex AR Test - สแกนความไว</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
    
    <!-- นำเข้าไลบรารี MediaPipe Hands และ Camera Utils เพื่อใช้กล้องจับการเคลื่อนไหวของนิ้วมือ -->
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js" crossorigin="anonymous"></script>

    <style>
        body { font-family: 'Prompt', sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        /* ซ่อนกล้องดิบเพื่อนำไปวาดและเล่นผ่าน Canvas เท่านั้น */
        #webcam-video {
            display: none;
        }
        canvas {
            transform: scaleX(-1); /* กลับข้างแบบกระจกเงาเพื่อให้ผู้เล่นเลื่อนมือได้ธรรมชาติ */
        }
    </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen flex flex-col justify-between">

    <!-- Header -->
    <header class="border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-50">
        <div class="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
            <span class="text-xl font-bold bg-gradient-to-r from-cyan-400 to-indigo-500 bg-clip-text text-transparent">NEXUS REFLEX AR TEST</span>
            <div class="flex items-center gap-4">
                <div class="text-right">
                    <span class="text-xs text-slate-400 block">ยินดีต้อนรับผู้สมัคร</span>
                    <span class="font-semibold text-sm text-indigo-300">🎮 @<?php echo htmlspecialchars($username); ?></span>
                </div>
                <a href="logout.php" class="bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs px-3 py-1.5 rounded transition">ออกจากระบบ</a>
            </div>
        </div>
    </header>

    <!-- Main Content Grid -->
    <main class="max-w-6xl mx-auto px-4 py-8 flex-grow grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        <!-- ฝั่งซ้าย: วิธีการเล่นและกระดานคะแนน -->
        <div class="space-y-6 lg:col-span-1">
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-6">
                <h2 class="text-lg font-bold mb-4 flex items-center gap-2">
                    <span>🎮</span> วิธีการเล่นแบบทดสอบ AR
                </h2>
                <ul class="space-y-3 text-sm text-slate-400">
                    <li class="flex gap-2">
                        <span class="text-cyan-400">1.</span>
                        <span>อนุญาตให้ระบบเข้าถึง <strong class="text-slate-200">กล้องเว็บแคม</strong> เมื่อมีการขอสิทธิ์</span>
                    </li>
                    <li class="flex gap-2">
                        <span class="text-cyan-400">2.</span>
                        <span>ชูมือขึ้นมาหน้ากล้อง ระบบจะทำการแสดงจุดมาร์กนิ้วบนจอ</span>
                    </li>
                    <li class="flex gap-2">
                        <span class="text-cyan-400">3.</span>
                        <span>เลื่อน <strong class="text-slate-200">ปลายนิ้วชี้</strong> ไปแตะ <span class="text-yellow-400 font-bold">⭐ ดาวสีเหลือง</span> ที่สุ่มเกิดบนหน้าจอ</span>
                    </li>
                    <li class="flex gap-2">
                        <span class="text-cyan-400">4.</span>
                        <span>เมื่อแตะโดนจะได้ <strong class="text-emerald-400">+1 คะแนน</strong> และดาวจะสุ่มไปเกิดจุดใหม่ทันที</span>
                    </li>
                    <li class="flex gap-2">
                        <span class="text-cyan-400">5.</span>
                        <span>มีเวลา <strong class="text-amber-400">30 วินาที</strong> ต่อรอบ คะแนนจะถูกบันทึกขึ้นฐานข้อมูลทันทีเมื่อเวลาหมด</span>
                    </li>
                </ul>
            </div>

            <!-- คะแนนและสถิติของผู้เล่น -->
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-6">
                <h3 class="text-sm text-slate-400 font-semibold mb-3 uppercase tracking-wider">สถิติส่วนบุคคล</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div class="bg-slate-950 p-4 rounded-lg border border-slate-800 text-center">
                        <span class="text-xs text-slate-400 block mb-1">คะแนนสูงสุดเดิม</span>
                        <span id="db-high-score" class="text-2xl font-black font-mono text-cyan-400"><?php echo $high_score; ?></span>
                    </div>
                    <div class="bg-slate-950 p-4 rounded-lg border border-slate-800 text-center">
                        <span class="text-xs text-slate-400 block mb-1">คะแนนรอบปัจจุบัน</span>
                        <span id="current-score-text" class="text-2xl font-black font-mono text-yellow-400">0</span>
                    </div>
                </div>
                
                <div class="mt-4 pt-4 border-t border-slate-800 text-center" id="save-status">
                    <span class="text-xs text-slate-500">ข้อมูลเชื่อมต่อกับฐานข้อมูล MySQL เรียบร้อย</span>
                </div>
            </div>

            <!-- ปุ่มเริ่มเกม -->
            <button id="start-game-btn" class="w-full bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold py-4 rounded-xl transition shadow-lg shadow-emerald-900/20 text-center flex justify-center items-center gap-2 cursor-pointer">
                <span>🚀</span> เริ่มต้นทดสอบความไว (30 วินาที)
            </button>
        </div>

        <!-- ฝั่งขวา: หน้าจอกล้องเว็บแคมและ AR Play Area -->
        <div class="lg:col-span-2 space-y-4">
            
            <div class="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden p-4 relative shadow-2xl">
                <!-- แถบด้านบนของ Area -->
                <div class="flex justify-between items-center mb-3">
                    <div class="flex items-center gap-2">
                        <span class="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                        <span class="text-xs text-slate-400 font-mono">LIVE WEB-CAMERA & AR RADAR</span>
                    </div>
                    <div class="bg-slate-950 px-3 py-1 rounded-full border border-slate-800 font-mono text-xs flex gap-2">
                        <span>เวลาเหลือ: </span>
                        <span id="timer-text" class="text-red-400 font-bold">30.00</span>s
                    </div>
                </div>

                <!-- พื้นที่แสดงผลเกม และกล้องจริง -->
                <div class="relative w-full aspect-video bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center">
                    
                    <!-- วิดีโอสดซ่อนไว้สำหรับนำพิกเซลไปส่งเข้า MediaPipe -->
                    <video id="webcam-video" autoplay playsinline></video>
                    
                    <!-- Canvas สำหรับวาดภาพจากกล้อง, ตัวละครมือจับ, และ ดาวสุ่ม -->
                    <canvas id="game-canvas" class="w-full h-full object-cover"></canvas>

                    <!-- แสดงข้อความสถานะโหลดระบบกล้อง -->
                    <div id="camera-loading-overlay" class="absolute inset-0 bg-slate-950 flex flex-col justify-center items-center gap-4 text-center px-4">
                        <div class="w-12 h-12 rounded-full border-4 border-indigo-500 border-t-transparent animate-spin"></div>
                        <div>
                            <p class="font-semibold text-slate-200">กำลังเปิดใช้งานกล้อง และโหลดโมเดลปัญญาประดิษฐ์ (MediaPipe)...</p>
                            <p class="text-xs text-slate-500 mt-1">กรุณากดอนุญาตให้เข้าถึงสิทธิ์กล้อง เพื่อทำการทดสอบ</p>
                        </div>
                    </div>

                    <!-- แสดงข้อความเมื่อเวลาหมด -->
                    <div id="game-over-overlay" class="absolute inset-0 bg-slate-950/90 backdrop-blur-sm hidden flex-col justify-center items-center gap-4 text-center px-4">
                        <span class="text-5xl">🏆</span>
                        <div>
                            <h3 class="text-2xl font-black text-white">หมดเวลาทดสอบความไว!</h3>
                            <p class="text-sm text-slate-300 mt-2">คะแนนของคุณในรอบนี้คือ: <span id="final-score" class="font-bold text-yellow-400 text-lg">0</span> คะแนน</p>
                            <p id="high-score-record-text" class="text-xs text-indigo-400 mt-1 font-semibold animate-pulse hidden">🔥 ยินดีด้วยคุณทำลายสถิติใหม่สำเร็จ!</p>
                            <p id="saving-indicator" class="text-xs text-slate-500 mt-3 flex items-center gap-1.5 justify-center">
                                <span class="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping"></span>
                                กำลังบันทึกคะแนนลงฐานข้อมูล...
                            </p>
                        </div>
                        <button id="restart-game-btn" class="mt-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-6 py-2.5 rounded-lg text-sm transition">
                            ทดสอบอีกครั้ง
                        </button>
                    </div>
                </div>
            </div>

            <!-- คำเตือน/หมายเหตุ -->
            <div class="bg-indigo-950/20 border border-indigo-900/50 p-4 rounded-xl flex gap-3 items-center text-slate-400 text-xs">
                <span>💡</span>
                <p><strong>แนะนำเพื่อการเล่นที่ดีที่สุด:</strong> จัดวางกล้องให้เห็นส่วนบนของร่างกายเต็มที่ และอยู่ในจุดที่มีแสงสว่างเพียงพอเพื่อช่วยให้ MediaPipe ตรวจพบนิ้วชี้ได้อย่างรวดเร็วและแม่นยำ</p>
            </div>
        </div>

    </main>

    <!-- Footer -->
    <footer class="border-t border-slate-900 bg-slate-950 py-6 text-center text-sm text-slate-500">
        <p>&copy; 2026 Nexus Esports Recruitment Program. All Rights Reserved.</p>
    </footer>

    <!-- โค้ด JavaScript จัดการเกมและการรับส่งข้อมูล AJAX -->
    <script>
        const videoElement = document.getElementById('webcam-video');
        const canvasElement = document.getElementById('game-canvas');
        const canvasCtx = canvasElement.getContext('2d');
        const overlayLoading = document.getElementById('camera-loading-overlay');
        const overlayGameOver = document.getElementById('game-over-overlay');
        
        const startBtn = document.getElementById('start-game-btn');
        const restartBtn = document.getElementById('restart-game-btn');
        const timerText = document.getElementById('timer-text');
        const currentScoreText = document.getElementById('current-score-text');
        const dbHighScoreText = document.getElementById('db-high-score');
        const finalScoreText = document.getElementById('final-score');
        const newRecordText = document.getElementById('high-score-record-text');
        const savingIndicator = document.getElementById('saving-indicator');

        // สถานะของเกม
        let isGameRunning = false;
        let score = 0;
        let timeLeft = 30.00; // เวลาวินาที
        let gameInterval = null;
        let starTarget = { x: 0, y: 0, radius: 25 }; // ตำแหน่งดาว
        let fingerTipPos = null; // ตำแหน่งปลายนิ้วชี้ (x, y) จาก MediaPipe
        let dbHighScore = <?php echo $high_score; ?>;

        // ฟังก์ชันวาดรูปดาวบน Canvas
        function drawStar(ctx, cx, cy, spikes, outerRadius, innerRadius) {
            let rot = Math.PI / 2 * 3;
            let x = cx;
            let y = cy;
            let step = Math.PI / spikes;

            ctx.beginPath();
            ctx.moveTo(cx, cy - outerRadius);
            for (let i = 0; i < spikes; i++) {
                x = cx + Math.cos(rot) * outerRadius;
                y = cy + Math.sin(rot) * outerRadius;
                ctx.lineTo(x, y);
                rot += step;

                x = cx + Math.cos(rot) * innerRadius;
                y = cy + Math.sin(rot) * innerRadius;
                ctx.lineTo(x, y);
                rot += step;
            }
            ctx.lineTo(cx, cy - outerRadius);
            ctx.closePath();
            ctx.lineWidth = 4;
            ctx.strokeStyle = '#f59e0b';
            ctx.stroke();
            ctx.fillStyle = '#fbbf24';
            ctx.fill();
        }

        // สุ่มพิกัดดาวดวงใหม่ โดยหลีกเลี่ยงขอบจอเกินไป
        function spawnStar() {
            if (canvasElement.width === 0) return;
            starTarget.x = Math.random() * (canvasElement.width - 100) + 50;
            starTarget.y = Math.random() * (canvasElement.height - 100) + 50;
        }

        // เริ่มเกม
        function startGame() {
            if (isGameRunning) return;
            
            isGameRunning = true;
            score = 0;
            timeLeft = 30.00;
            currentScoreText.innerText = score;
            timerText.innerText = timeLeft.toFixed(2);
            
            overlayGameOver.classList.add('hidden');
            newRecordText.classList.add('hidden');
            
            spawnStar();

            // เริ่มเวลาถอยหลัง
            const startTick = Date.now();
            gameInterval = setInterval(() => {
                const elapsed = (Date.now() - startTick) / 1000;
                timeLeft = 30.00 - elapsed;

                if (timeLeft <= 0) {
                    timeLeft = 0;
                    endGame();
                }
                timerText.innerText = timeLeft.toFixed(2);
            }, 50);
        }

        // จบเกมและส่งคะแนนไปเซฟใน MySQL ผ่าน AJAX
        function endGame() {
            isGameRunning = false;
            clearInterval(gameInterval);
            
            finalScoreText.innerText = score;
            overlayGameOver.classList.remove('hidden');
            
            if (score > dbHighScore) {
                newRecordText.classList.remove('hidden');
            }

            savingIndicator.innerHTML = '<span class="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping"></span> กำลังบันทึกคะแนนลงฐานข้อมูล...';
            
            // ส่งค่าด้วย Fetch API (AJAX เพื่อส่งแบบ Real-time)
            fetch('update_score.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ score: score })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    savingIndicator.innerHTML = '✅ บันทึกข้อมูลสำเร็จ! คะแนนสูงสุดของคุณ: <strong class="text-cyan-400 font-bold">' + data.new_high_score + '</strong>';
                    dbHighScore = data.new_high_score;
                    dbHighScoreText.innerText = dbHighScore;
                } else {
                    savingIndicator.innerHTML = '❌ บันทึกล้มเหลว: ' + data.message;
                }
            })
            .catch(error => {
                savingIndicator.innerHTML = '❌ บันทึกล้มเหลว (เครือข่ายผิดพลาด)';
                console.error('Error updating score:', error);
            });
        }

        // จัดการผลลัพธ์จาก MediaPipe Hands เพื่อวาดภาพลง Canvas
        function onResults(results) {
            // ซ่อนหน้าจอโหลดเมื่อสัญญาณภาพกล้องมาแล้ว
            overlayLoading.classList.add('hidden');

            const width = canvasElement.width = videoElement.videoWidth || 640;
            const height = canvasElement.height = videoElement.videoHeight || 480;

            // 1. วาดวิดีโอจากกล้องลงบน Canvas (กลับซ้ายขวาเพื่อการเล่นแบบกระจก)
            canvasCtx.save();
            canvasCtx.clearRect(0, 0, width, height);
            canvasCtx.drawImage(results.image, 0, 0, width, height);

            // 2. หากจับนิ้วมือได้
            fingerTipPos = null;
            if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
                for (const landmarks of results.multiHandLandmarks) {
                    // วาดจุดเชื่อมโยงนิ้วมือ
                    // landmark ที่ 8 คือ ปลายนิ้วชี้ (Index Finger Tip)
                    const indexTip = landmarks[8];
                    
                    // เนื่องจาก canvas ใน CSS ถูกกลับข้างด้วย scaleX(-1) แต่ Coordinates ที่ MediaPipe ส่งมายังคงอิงจากกล้องดิบ
                    // เพื่อให้วาดบน Canvas และทับกับดาวได้เป๊ะๆ เราจะคำนวณตำแหน่งพิกเซลจริง
                    const px = indexTip.x * width;
                    const py = indexTip.y * height;
                    
                    fingerTipPos = { x: px, y: py };

                    // วาดจุดสีแสดบอกสถานะปลายนิ้วชี้
                    canvasCtx.beginPath();
                    canvasCtx.arc(px, py, 12, 0, 2 * Math.PI);
                    canvasCtx.fillStyle = '#ff4500';
                    canvasCtx.shadowColor = '#ff4500';
                    canvasCtx.shadowBlur = 15;
                    canvasCtx.fill();
                    canvasCtx.lineWidth = 3;
                    canvasCtx.strokeStyle = '#ffffff';
                    canvasCtx.stroke();
                    canvasCtx.shadowBlur = 0; // รีเซ็ตเอฟเฟกต์เบลอ

                    // วาดโครงกระดูกมือนิ้วอื่นๆ ย่อๆ
                    for (let i = 0; i < landmarks.length; i++) {
                        if (i !== 8) { // จุดอื่นๆ วาดเล็กๆ สีฟ้า
                            canvasCtx.beginPath();
                            canvasCtx.arc(landmarks[i].x * width, landmarks[i].y * height, 4, 0, 2 * Math.PI);
                            canvasCtx.fillStyle = '#06b6d4';
                            canvasCtx.fill();
                        }
                    }
                }
            }

            // 3. วาดดาว และตรวจสอบว่านิ้วชนดาวหรือไม่เมื่อเกมกำลังเริ่ม
            if (isGameRunning) {
                // วาดเป้าดาวสะท้อนแสง
                drawStar(canvasCtx, starTarget.x, starTarget.y, 5, starTarget.radius, starTarget.radius / 2.2);

                // หากจับนิ้วชี้ได้ และอยู่ห่างจากเป้าดาวน้อยกว่าระยะสัมผัส
                if (fingerTipPos) {
                    // คำนวณระยะห่างระหว่างจุดชน 2 มิติ (นิ้วกับศูนย์กลางดาว)
                    // หมายเหตุ: เนื่องจาก Canvas กลับข้าง (Mirror) พิกเซล X บนหน้าจอ จะต้องสอดคล้องกัน
                    const dx = fingerTipPos.x - starTarget.x;
                    const dy = fingerTipPos.y - starTarget.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);

                    // ถ้าระยะนิ้วชี้และดาว อยู่ในระยะชน (35 พิกเซลรวมรัศมี)
                    if (distance < (starTarget.radius + 15)) {
                        score += 1;
                        currentScoreText.innerText = score;
                        
                        // มีเสียงบี๊บจำลองเพื่อเป็นสัญญาณการเก็บคะแนน
                        playBeepSound();

                        // ย้ายดาวไปเกิดสุ่มในจุดใหม่ทันที
                        spawnStar();
                    }
                }
            }
            
            canvasCtx.restore();
        }

        // ฟังก์ชันสร้างเสียง Beep สั้นๆ จำลองเมื่อผู้เล่นสัมผัสหน้าดาว
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        function playBeepSound() {
            try {
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(880, audioCtx.currentTime); // โน้ต A5 คมชัด
                gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.15);
                osc.connect(gain);
                gain.connect(audioCtx.destination);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.15);
            } catch (e) {
                // เบราว์เซอร์บล็อกเสียงเป็นเรื่องปกติหากยังไม่ได้คลิกหน้าจอเป็นครั้งแรก
            }
        }

        // ตั้งค่าโมเดล MediaPipe Hands
        const hands = new Hands({
            locateFile: (file) => {
                return 'https://cdn.jsdelivr.net/npm/@mediapipe/hands/' + file;
            }
        });

        hands.setOptions({
            maxNumHands: 1,
            modelComplexity: 1,
            minDetectionConfidence: 0.5,
            minTrackingConfidence: 0.5
        });

        hands.onResults(onResults);

        // เปิดใช้งานกล้องผ่านเว็บแคม
        const camera = new Camera(videoElement, {
            onFrame: async () => {
                await hands.send({ image: videoElement });
            },
            width: 640,
            height: 480
        });

        // เปิดรันระบบกล้อง
        camera.start().catch(err => {
            overlayLoading.innerHTML = '❌ การเปิดกล้องเว็บแคมล้มเหลว: <br>' + err.message + '<br><br>กรุณาตรวจสอบว่าติดตั้งเว็บแคมแล้ว และได้รับสิทธิ์แล้ว';
            console.error('Webcam start failed:', err);
        });

        // ผูกการทำงานปุ่มต่างๆ
        startBtn.addEventListener('click', startGame);
        restartBtn.addEventListener('click', startGame);

    </script>
</body>
</html>`
  },
  {
    filename: 'update_score.php',
    description: 'สคริปต์ AJAX/Fetch API เบื้องหลัง ใช้ตรวจสอบและอัปเดตคะแนนสูงสุดผู้ใช้ลง MySQL',
    language: 'php',
    content: `<?php
session_start();
require_once 'db_connect.php';

// บังคับส่งประเภทเนื้อหาให้เป็น JSON เสมอเพื่อตอบกลับ AJAX คลีนๆ
header('Content-Type: application/json; charset=utf-8');

// หากไม่ได้ล็อกอิน ไม่อนุญาตให้เซฟคะแนน
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'คุณยังไม่ได้เข้าสู่ระบบ!'
    ]);
    exit();
}

$user_id = $_SESSION['user_id'];

// รับข้อมูล JSON ที่ส่งจาก Fetch API
$input_data = file_get_contents('php://input');
$data = json_decode($input_data, true);

if ($data && isset($data['score'])) {
    $new_score = intval($data['score']);

    try {
        // 1. ตรวจสอบคะแนนสูงสุดเดิมในระบบก่อน
        $stmt = $conn->prepare("SELECT high_score FROM users WHERE id = :id");
        $stmt->execute(['id' => $user_id]);
        $current_high_score = intval($stmt->fetchColumn());

        $final_high_score = $current_high_score;

        // 2. ถ้าคะแนนรอบใหม่สูงกว่า ให้ทำการอัปเดตค่า
        if ($new_score > $current_high_score) {
            $update_stmt = $conn->prepare("UPDATE users SET high_score = :score WHERE id = :id");
            $update_stmt->execute([
                'score' => $new_score,
                'id' => $user_id
            ]);
            $final_high_score = $new_score;
            $_SESSION['high_score'] = $final_high_score; // อัปเดตใน session ผู้ใช้ด้วย
        }

        echo json_encode([
            'status' => 'success',
            'message' => 'คะแนนประเมินสำเร็จ',
            'score_sent' => $new_score,
            'new_high_score' => $final_high_score,
            'is_new_record' => ($new_score > $current_high_score)
        ]);
        exit();

    } catch (PDOException $e) {
        echo json_encode([
            'status' => 'error',
            'message' => 'ข้อผิดพลาดเกี่ยวกับฐานข้อมูล: ' . $e->getMessage()
        ]);
        exit();
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'ข้อมูลคะแนนไม่สมบูรณ์!'
    ]);
    exit();
}
?>`
  },
  {
    filename: 'logout.php',
    description: 'ไฟล์เคลียร์เซสชันเมื่อออกจากระบบ',
    language: 'php',
    content: `<?php
session_start();
// เคลียร์ข้อมูล session ทั้งหมด
$_SESSION = array();

// ทำลาย session
session_destroy();

// นำกลับไปยังหน้าแรกล็อกอิน
header("Location: index.php");
exit();
?>`
  },
  {
    filename: 'README_SETUP.md',
    description: 'คู่มือวิธีนำโค้ดทั้งหมดนี้ไปรันบน XAMPP',
    language: 'markdown',
    content: `# คู่มือการเซ็ตอัปโปรเจกต์ Esports Recruitment ใน XAMPP

โปรเจกต์นี้ได้รับการพัฒนาด้วยภาษา **PHP, MySQL, HTML5 และ JavaScript** พร้อมเสริมเทคโนโลยีกล้องด้วย **MediaPipe AR** สำหรับทดสอบความไวการตอบสนอง

---

## 🛠️ ขั้นตอนการรันโปรเจกต์บนเครื่องคอมพิวเตอร์ของคุณ (XAMPP)

### 1. การเตรียมโฟลเดอร์สำหรับรันโปรแกรม
1. เปิดโปรแกรม **XAMPP Control Panel** และตรวจสอบให้มั่นใจว่าได้กดปุ่ม **Start** ที่บริการ \`Apache\` และ \`MySQL\` เรียบร้อยแล้ว
2. สร้างโฟลเดอร์ใหม่ภายใต้โฟลเดอร์ \`htdocs\` ของ XAMPP (ปกติอยู่ที่ \`C:\\xampp\\htdocs\\\`) เช่น ตั้งชื่อว่า **\`esports-recruit\`**
   - เส้นทางจะเป็น: \`C:\\xampp\\htdocs\\esports-recruit\`
3. คัดลอกและสร้างไฟล์ PHP ทั้งหมดในเครื่องของคุณ ดังรายชื่อต่อไปนี้ไปใส่ในโฟลเดอร์นั้น:
   - \`db_connect.php\`
   - \`index.php\`
   - \`register.php\`
   - \`game.php\`
   - \`update_score.php\`
   - \`logout.php\`

---

### 2. การสร้างและนำเข้าฐานข้อมูล MySQL
1. เปิดเบราว์เซอร์ไปที่ลิงก์ **[http://localhost/phpmyadmin](http://localhost/phpmyadmin)**
2. คลิกแท็บ **"SQL"** ที่แถบเมนูด้านบน
3. คัดลอกข้อความคำสั่ง SQL ทั้งหมดจากไฟล์ \`database.sql\` ในโปรเจกต์นี้ มาวางลงในช่องสำหรับรันคำสั่ง
4. คลิกปุ่ม **"Go"** (หรือ **"ลงมือ"**) ที่มุมล่างขวาเพื่อรันคำสั่งสร้างฐานข้อมูลและตาราง
5. ระบบจะทำการสร้างฐานข้อมูลชื่อ \`esports_db\` และสร้างตารางชื่อ \`users\` โดยอัตโนมัติ

---

### 3. เริ่มต้นใช้งานโปรแกรมในหน้าเบราว์เซอร์
1. เปิดเว็บเบราว์เซอร์แล้วเข้าไปที่ลิงก์: **[http://localhost/esports-recruit/index.php](http://localhost/esports-recruit/index.php)**
2. ทำการสมัครสมาชิกในหน้าลงทะเบียน (\`register.php\`)
3. ล็อกอินเข้าใช้งานด้วยบัญชีที่สร้างขึ้น
4. ระบบจะนำพาเข้าสู่หน้าเล่นเกม AR (\`game.php\`) เพื่อทดสอบความเร็วมือสัมผัสดาว!

---

## 💡 คำแนะนำและข้อแนะนำเพิ่มเติมเกี่ยวกับการใช้กล้อง AR

- **สิทธิ์การใช้กล้อง (SSL/HTTPS):** ในการรันบน \`localhost\` ระบบปฏิบัติการส่วนใหญ่จะอนุญาตให้เว็บใช้กล้องเว็บแคมได้ทันทีโดยไม่ต้องใช้ HTTPS อย่างไรก็ตาม หากใช้งานผ่านเครือข่าย IP ท้องถิ่นอื่นๆ (เช่น \`192.168.x.x\`) เบราว์เซอร์รุ่นใหม่ๆ อาจจะบล็อกการเปิดใช้งานกล้องหากยังไม่มีใบรับรองความปลอดภัย (SSL/HTTPS)
- **แสงสว่างและการวางมือ:** โปรแกรมจะทำงานได้เต็มร้อยเมื่อสโมสรหรือผู้เล่นจัดแสงสว่างในห้องให้เห็นมือชัดเจน และจัดวางกล้องให้เห็นฝ่ามือเต็มที่เพื่อช่วยให้ระบบ AI ของ MediaPipe ตรวจจับปลายนิ้วชี้ได้อย่างลื่นไหลไร้รอยต่อ
`
  }
];
